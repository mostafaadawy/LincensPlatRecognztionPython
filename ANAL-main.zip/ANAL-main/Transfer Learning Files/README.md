plates_ssd_mnet_v1_quant_edgetpu.tflite was trained for 5-10 minutes and only for the last few layers.

plates.tflite in the main directory was trained for 24 hours (IIRC) and for the entire model.
