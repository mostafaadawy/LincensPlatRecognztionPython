# Automatic Number-Plate Analysis Legend (ANAL)

> Automatic Number-Plate Analysis Legend code

This repo contains the source code from my number plate recognition system from this video:

[![IMAGE ALT TEXT](http://img.youtube.com/vi/uwnG50Hatw0/0.jpg)](http://www.youtube.com/watch?v=uwnG50Hatw0 "This ANPR Car Mod Is A Privacy Nightmare! (Automatic Number Plate Recognition)")


Watch the full walkthrough from coding to car installation, here:

[![IMAGE ALT TEXT](http://img.youtube.com/vi/6xklN4iiA0Q/0.jpg)](http://www.youtube.com/watch?v=6xklN4iiA0Q "[Python ANPR Course] Install Automatic Number Plate Recognition In Your Car!")
